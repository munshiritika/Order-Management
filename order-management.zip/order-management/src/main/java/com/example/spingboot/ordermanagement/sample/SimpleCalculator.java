package com.example.spingboot.ordermanagement.sample;
//03-08-2024, Friday

public class SimpleCalculator {
	public int sum(int a, int b) {
		return a+b;
	}
	
	public int diff(int a, int b) {
		return a-b;
	}
	
	public int mul(int a, int b) {
		return a*b;
	}
	
	public int div(int a, int b) {
		return a/b;
	}
}
