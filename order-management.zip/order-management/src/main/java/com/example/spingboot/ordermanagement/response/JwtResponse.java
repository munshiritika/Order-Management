package com.example.spingboot.ordermanagement.response;
//03-14-2024, Thursday

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class JwtResponse {
	private final String token;
	
}
