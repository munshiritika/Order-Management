package com.example.spingboot.ordermanagement.service;
//02-28-2024, Wednesday

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.example.spingboot.ordermanagement.dao.CustomerDao;
import com.example.spingboot.ordermanagement.model.Customer;
import com.example.spingboot.ordermanagement.request.CustomerRequest;

@Service  //it contains business logic
//We will write the business logic here
public class CustomerService {
	Logger logger = LoggerFactory.getLogger(CustomerService.class);
	
	@Autowired
	private CustomerDao customerDao;
	
	public Customer saveCustomer(CustomerRequest inputCustomerRequest) {
		//Step 1: create customer object
		//Step 2: get inputCustomerRequest values and set it in customer object
		//Step 3: save customer object
		
		logger.info("saveCustomer method has started.");
		Customer customer = new Customer();
	
		customer.setCustomerName(inputCustomerRequest.getCustomerName());
		customer.setEmail(inputCustomerRequest.getEmail());
		customer.setMobile(inputCustomerRequest.getMobile());
		customer.setAddress(inputCustomerRequest.getAddress());
		customer.setPassword(inputCustomerRequest.getPassword());
	
		Customer savedCustomer = customerDao.save(customer);
		if(savedCustomer == null) {
			logger.error("Customer could not be saved because savedCustomer is null.");
			throw new RuntimeException("Customer not saved in the database.");
		}
		logger.info("Customer saved and saveCustomer method ended.");
		return savedCustomer;
	}
	
	public List<Customer> getAllCustomers() {
		logger.info("getAllCustomers method has started.");
		List<Customer> customerList = customerDao.findAll();
		if(customerList.isEmpty()) {
			logger.info("All Customers could not be found because customerList is null.");
			throw new RuntimeException("Customer not found in the database.");
		}
		logger.info("All Customer found and getAllCustomers method ended.");
		return customerList;
	}
	
	public Customer getCustomerById(long customerId) {
		logger.info("getCustomerById method has started.");
		//customer by that id might be present or might not be present so optional. You will get the data if it is there or you will not get the data if there is not that customer with that id
		Optional<Customer> customerOptional = customerDao.findById(customerId);
		if(customerOptional.isEmpty()) {
			logger.info("Customers could not be found for customerId: " + customerId + "  because customerOptional is empty.");
			throw new RuntimeException("Customer for customerId: " + customerId + " not found in the database.");
		}
		Customer customerFromDatabase = customerOptional.get();
		logger.info("Customer found for customerId: " + customerId + " and getCustomerById method ended.");
		return customerFromDatabase;
	}
	
	public long getAllCustomersCount() {
		logger.info("getAllCustomersCount method has started.");
		long totalcount = customerDao.count();
		if(totalcount == 0) {
			logger.info("Customer count could not be found because totalcount is 0.");
			throw new RuntimeException("Customer Count is not present in the database.");
		}
		logger.info("Customers count found and getAllCustomersCount method ended.");
		return totalcount;
	}
	
	public Customer updateCustomer(long customerId, CustomerRequest newCustomerRequest) {
		//Step 1: find whether the customer is present in the database or not using getCustomerById method
		//Step 2: if the customer is present in database update the oldValues of the customers to the new inputValues
		//Step 3: save the oldCustomer which now has updated values
		logger.info("getAllCustomersCount method has started.");
		Customer updatedCustomer = null;
		
		Customer oldExistingCustomer = getCustomerById(customerId);
		
		if(oldExistingCustomer != null) {
			oldExistingCustomer.setCustomerName(newCustomerRequest.getCustomerName());
			oldExistingCustomer.setEmail(newCustomerRequest.getEmail());
			oldExistingCustomer.setMobile(newCustomerRequest.getMobile());
			oldExistingCustomer.setAddress(newCustomerRequest.getAddress());
			oldExistingCustomer.setPassword(newCustomerRequest.getPassword());
		}
		
		updatedCustomer = customerDao.save(oldExistingCustomer);
		if(updatedCustomer == null) {
			logger.info("Customer could not be updated because updatedCustomer is null.");
			throw new RuntimeException("Customer not updated in the database.");
		}
		logger.info("Customers updated and updateCustomer method ended.");
		return updatedCustomer;
	}
	
	public void deleteCustomerbyId(long customerId) {
		logger.info("deleteCustomerbyId method has started.");
		customerDao.deleteById(customerId);
		if(customerId < 1) {
			logger.info("Customer could not be deleted because customerId is not found.");
			throw new RuntimeException("Customer not deleted based on the customerId in the database.");
		}
		logger.info("Customers deleted and deleteCustomerbyId method ended.");
	}
	
	public Customer findCustomerByEmail(String email) {
		logger.info("findCustomerByEmail method has started.");
		Customer customer = customerDao.getCustomerByEmail(email);
		if(customer == null) {
			logger.info("Customer could not be found by email because customer is null.");
			throw new RuntimeException("Customer not found based on the email in the database.");
		}
		logger.info("Customers found by email and findCustomerByEmail method ended.");
		return customer;
	}
	
	public List<Customer> findCustomerBasedOnCity(String city) {
		logger.info("findCustomerBasedOnCity method has started.");
		List<Customer> customer = customerDao.getCustomersBasedOnCity(city);
		if(customer.isEmpty()) {
			logger.info("Customer could not be found by city because customer is null.");
			throw new RuntimeException("Customer not found based on the city in the database.");
		}
		logger.info("Customers found by city and findCustomerBasedOnCity method ended.");
		return customer;
	}
	
	/*
	 * pagination - fetching records or data based on pages 
	 * two inputs - page number we want to see and page size
	 * 
	 * Example:
	 * total records - 37
	 * page size - 10
	 * 0th page - 10
	 * 1st page - 1-10
	 * 2nd page - 11-20
	 * 3rd page - 21-30
	 * 4th page - 31-37
	 * 
	 * sorting - arranging the records based on specific field in either ascending or descending order
	 * 
	 * sorting and pagination both comes together meaning they are done together
	 */
	
	public List<Customer> getAllCustomersWithPage(Integer pageNumber, Integer pageSize) {
		logger.info("getAllCustomersWithPage method has started.");
		//If we want to Perform only pagination
		//Page<Customer> customerPage = customerDao.findAll(PageRequest.of(pageNumber, pageSize));
		//pagination along with sorting - be default ascending order
		Page<Customer> customerPage = customerDao.findAll(PageRequest.of(pageNumber, pageSize, Sort.by("customerName").ascending()));
		//we need to convert customerPage to the list of customer
		List<Customer> customerList = new ArrayList<>();
		for(Customer customer: customerPage) {
			customerList.add(customer);
		}
		logger.info("Customers found by with page and getAllCustomersWithPage method ended.");
		return customerList;
	}

}
