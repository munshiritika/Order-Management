package com.example.spingboot.ordermanagement;
//02-22-2024, Thursday
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Rule of Spring Boot is to create package within this main package not outside this package from src main java 
@SpringBootApplication
public class OrderManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderManagementApplication.class, args);
	}

}
