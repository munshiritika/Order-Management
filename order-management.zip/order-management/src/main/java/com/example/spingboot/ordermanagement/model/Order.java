package com.example.spingboot.ordermanagement.model;
//02-26-2024, Monday

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="orders")
@Data
@AllArgsConstructor  
@NoArgsConstructor   
public class Order {
	@Id
	@Column(name="order_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long orderId;
	@Column(name="prd_pur_qnt", nullable = false)
	private String productPurchaseQuantity;
	@Column(name="total_price", nullable = false)
	private String totalPrice;
	@Column(name="delivery_address", nullable=false)
	private String deliveryAddress;
	@Column(name="order_status",nullable=false)
	private String orderStatus;
	@Column(name="payment_method",nullable=false)
	private String paymentMethod;
	//Eager: fetches data just by id: load the data
	//LAZY: won't fetch any data: won't display any data
	//@JoinColumn: name should be same as primary key name of customer and product table
	//order to product: Many to One: many order and one product
	@ManyToOne(fetch = FetchType.EAGER)  
	@JoinColumn(name = "product_id",nullable=false)  //foreign key
	private Product product;
	//order to customer: Many to One: one customer and many orders
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "customer_id",nullable=false)  //foreign key
	private Customer customer;
	
}
