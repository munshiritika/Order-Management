package com.example.spingboot.ordermanagement.util;
//03-13-2024, Wednesday

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import com.example.spingboot.ordermanagement.service.JwtUserDetailsService;

@Component
public class JwtFilter extends OncePerRequestFilter {
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		//Token is passed in this format, Authorization: Bearer token-value-for-authorization
		String tokenHeader = request.getHeader("Authorization");  //it gives Bearer token-value-for-authorization
		String usernameFromToken = null;
		String tokenWithoutBearer = null;
		
		if(tokenHeader != null && tokenHeader.startsWith("Bearer ")) {  //then it is JWT token
			tokenWithoutBearer = tokenHeader.substring(7);  //it will remove Bearer and give token-value-for-authorization
			try {
				usernameFromToken = jwtUtil.getUsernameFromToken(tokenWithoutBearer);			
				}
			catch(Exception e){
				System.out.println("Unable to get username from token.");
			}
		}
		else {
			System.out.println("Bearer token is not passed correctly.");
		}
		
		if(usernameFromToken != null) { //if userName from token is not null.
			UserDetails userDetailsFromDb = jwtUserDetailsService.loadUserByUsername(usernameFromToken);  //fetch old details from database
			if(jwtUtil.validateJwtToken(tokenWithoutBearer, userDetailsFromDb)) { //check if token is valid.
				//create userName password object and set authentication details into that as web authentication details source
				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(userDetailsFromDb, null, userDetailsFromDb.getAuthorities());
				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				//set authentication mechanism in as security context holder
				//SecurityContextHolder is responsible for adding security to your authentication
				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
			}
		}
		//it will do for the next set of things from remaining portion of the API and where next step is calling API and filter chain will help calling API next
		filterChain.doFilter(request, response);
	}

}
