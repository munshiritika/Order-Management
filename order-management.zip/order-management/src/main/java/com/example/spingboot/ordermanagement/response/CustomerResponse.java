package com.example.spingboot.ordermanagement.response;
//03-06-2024, Wednesday

import com.example.spingboot.ordermanagement.model.Customer;
import lombok.Data;

@Data
public class CustomerResponse {
	private Customer data;
	private String message;
	private String code;
	
	/*
	 * 200 - OK
	 * 401 - UNAUTHORIZED
	 * 404 - NOT FOUND
	 * 500 - INTERNAL SERVER ERROR
	 * 400 - BADREQUEST
	 */

}
