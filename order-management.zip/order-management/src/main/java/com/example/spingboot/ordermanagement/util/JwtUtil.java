package com.example.spingboot.ordermanagement.util;
//03-13-2024, Wednesday

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil implements Serializable {
	//service class service annotation
	//methods for generating and validating utility token
	
	//Step 1: define expiration time in MS
	private static final long TOKEN_VALIDITY = 2*60*60*1000;  //2 hours to milliseconds
	
	//Step 2: take secret value from application.properties and assign it to variable
	@Value("${secret}")
	private String jwtSecret;
	
	//Step 3: generate JWT token
	public String generateJwtToken(UserDetails userDetails) {
		Map<String, Object> claims = new HashMap<>();
		return Jwts.builder().setClaims(claims).setSubject(userDetails.getUsername()).setIssuedAt(new Date(System.currentTimeMillis())).setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY)).signWith(SignatureAlgorithm.HS512, jwtSecret).compact();
	}
	
	//Step 4: validate JWT token
	//validate the userName from token and userName from userDetails
	public Boolean validateJwtToken(String token, UserDetails userDetails) {
		String tokenUsername = getUsernameFromToken(token);
		//we need to get expiration time
		final Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		Boolean isTokenExpired = claims.getExpiration().before(new Date());
		
		if(tokenUsername.equals(userDetails.getUsername()) && !isTokenExpired) {
			return true;  //valid token
		}
		else {
			return false;  //invalid token
		}
	}
	
	//get userName from JWT token
	public String getUsernameFromToken(String token) {
		final Claims claims = Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody();
		return claims.getSubject();  //subject contains userName
		//could also do claims.getExpirationDate or whatever details you want to get
	}
	
	
}
