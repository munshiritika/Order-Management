package com.example.spingboot.ordermanagement.request;
//03-14-2024, Thursday

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class JwtRequest {
	private String username;  //userName is email
	private String password;
}
