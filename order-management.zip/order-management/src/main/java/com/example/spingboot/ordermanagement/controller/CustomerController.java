package com.example.spingboot.ordermanagement.controller;
//02-28-2024, Wednesday

import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.example.spingboot.ordermanagement.model.Customer;
import com.example.spingboot.ordermanagement.request.CustomerRequest;
import com.example.spingboot.ordermanagement.response.CustomerResponse;
import com.example.spingboot.ordermanagement.service.CustomerService;

@RestController
@RequestMapping("/om/customer/v1")  //Name of API: order Management/Customer Entity/Version 1
public class CustomerController {
	/*
	 * API- Application Programming Interface - communication bridge between request and response (entry point where our requests start executing)
	 * 
	 * REST API - Representational State Transfer API - is used to handle HTTP web requests
	 * 
	 * HTTP methods for REST API -
	 * 
	 * POST - create/save/insert/add. 
	 * GET - fetch/read/find
	 * DELETE - delete
	 * PUT/PATCH - update
	 * 
	 * Post can perform all the operations like get, delete, put/patch. But in Spring Boot we have specifics.
	 * ------------------------------------------------------------------------------------------------------
	 * 
	 * Loggers - used to log messages of the application which is used to tace the application easily
	 * it maintains the hierarchy history of the application
	 * 4 levels of loggers -
	 * info - to give the information about application
	 * warn - to give warning messages
	 * error - to display error/exception message
	 * debug - to display logs at debug mode
	 * -----------------------------------------------------------------------------------------------
	 * 
	 * RestTemplate - calling one API inside other API
	 */
	
	//for information of the logger we need to declare the logger object from slf4j
	Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	RestTemplate restTemplate = new RestTemplate();
	
	@Autowired
	private CustomerService customerService;
	
	//In Spring Boot in API any input should be in the form of JSON
	//@RequestBody - it takes input from front end or UI in the form of JSON and passes it to API
	@PostMapping(value="/save")
	public ResponseEntity<?> createCustomer(@RequestBody CustomerRequest customerRequest) {
		logger.info("createCustomer API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			Customer customer = customerService.saveCustomer(customerRequest);
			customerResponse.setData(customer);
			customerResponse.setMessage("Customer saved successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customer saved successfuly and createCustomer API ended.");
			return ResponseEntity.ok().body(customer);
		}
		catch(Exception e){
			logger.info("Some error occured while saving customer.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not saved successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}		
	}
	
	@GetMapping(value="/findall")
	public ResponseEntity<?> findAllCustomers() {
		logger.info("findAllCustomers API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			List<Customer> customerList = customerService.getAllCustomers();
			customerResponse.setData(null);
			customerResponse.setMessage("All Customers found successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("All Customers found successfuly and findAllCustomers API ended.");
			return ResponseEntity.ok().body(customerList);
		}
		catch(Exception e){
			logger.info("Some error occured while finding all customers.");
			customerResponse.setData(null);
			customerResponse.setMessage("All Customer not found successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	//@PathVariable - this PathVariable is will be sent in the, it is passed inside URI as input
	@GetMapping(value="/find/{customerid}")
	public ResponseEntity<?> findCustomerById(@PathVariable("customerid") long customerId) {
		logger.info("findCustomerById API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			Customer customer = customerService.getCustomerById(customerId);
			customerResponse.setData(customer);
			customerResponse.setMessage("Customer for customerId: " + customerId + " found successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers found successfuly for customerId: " + customerId + " and findCustomerById API ended.");
			return ResponseEntity.ok().body(customerResponse);
		}
		catch(Exception e){
			logger.info("Some error occured while finding customer for customerId: " + customerId + ".");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer for customerId: " + customerId + " not found successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	@GetMapping(value="/findcount")
	public ResponseEntity<?> findCustomerCount() {
		logger.info("findCustomerCount API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			long totalcount = customerService.getAllCustomersCount();
			customerResponse.setData(null);
			customerResponse.setMessage("Customer count found successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers count found successfuly and findCustomerCount API ended.");
			return ResponseEntity.ok().body("The total customers present are: " + totalcount + ".");
		}
		catch(Exception e){
			logger.info("Some error occured while finding count of the customers.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer count not found successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}		
	}
	
	@PutMapping(value="/update/{customerid}")
	public ResponseEntity<?> updateCustomer(@RequestBody CustomerRequest customerRequest, @PathVariable("customerid") long customerId) {
		logger.info("updateCustomer API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			Customer updatedCustomer = customerService.updateCustomer(customerId, customerRequest);
			customerResponse.setData(updatedCustomer);
			customerResponse.setMessage("Customer updated successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers updated successfuly for the customerId: " + customerId + " and updateCustomer API ended.");
			return ResponseEntity.ok().body(updatedCustomer);
		}
		catch(Exception e){
			logger.info("Some error occured while updating the customers.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not updated successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	@DeleteMapping(value="/delete/{customerid}")
	public ResponseEntity<?> deleteCustomerById(@PathVariable("customerid") long customerId) {
		logger.info("deleteCustomerById API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			customerService.deleteCustomerbyId(customerId);
			customerResponse.setData(null);
			customerResponse.setMessage("Customer deleted successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers deleted successfuly for the customerId: " + customerId + " and deleteCustomerById API ended.");
			return ResponseEntity.ok().body("Customer with id: " + customerId + " got deleted successfully.");
		}
		catch(Exception e){
			logger.info("Some error occured while deleting the customers.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not deleted successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	@GetMapping(value="/findbyemail")
	public ResponseEntity<?> findCustomerByEmail(@RequestParam("email") String email) {
		logger.info("findCustomerByEmail API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			Customer customer = customerService.findCustomerByEmail(email);
			customerResponse.setData(customer);
			customerResponse.setMessage("Customer found by email successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers found successfuly for the email " + email + " and findCustomerByEmail API ended.");
			return ResponseEntity.ok().body(customer);
		}
		catch(Exception e){
			logger.info("Some error occured while finding customer based on the email.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not be found by email successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	@GetMapping(value="/customerbasedoncity")
	public ResponseEntity<?> findAllCustomersBasedOnCity(@RequestParam("city") String city) {
		logger.info("findAllCustomersBasedOnCity API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			List<Customer> customerList = customerService.findCustomerBasedOnCity(city);
			customerResponse.setData(null);
			customerResponse.setMessage("Customer found by city successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("Customers found successfuly for the city " + city + " and findAllCustomersBasedOnCity API ended.");
			return ResponseEntity.ok().body(customerList);
		}
		catch(Exception e){
			logger.info("Some error occured while finding customer based on the city.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not be found by city successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}		
	}
	
	@GetMapping(value="/findcustomerswithpage")
	public ResponseEntity<?> findAllCustomersWithPage(@RequestParam("pageNumber") Integer pageNumber, @RequestParam("pageSize") Integer pageSize) {
		logger.info("findAllCustomersWithPage API has started.");
		CustomerResponse customerResponse = new CustomerResponse();
		try {
			List<Customer> customerList = customerService.getAllCustomersWithPage(pageNumber, pageSize);
			customerResponse.setData(null);
			customerResponse.setMessage("Customer found by page successfully.");
			customerResponse.setCode(HttpStatus.OK.toString());
			logger.info("All Customers with pages found successfuly and findAllCustomersWithPage API ended.");
			return ResponseEntity.ok().body(customerList);
		}		
		catch(Exception e){
			logger.info("Some error occured while finding all customers with the page.");
			customerResponse.setData(null);
			customerResponse.setMessage("Customer not be found by page successfully.");
			customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
			return ResponseEntity.internalServerError().body(customerResponse);
		}
	}
	
	//REST template using REST API for get operation
	//First way to get for external URL
	@GetMapping(value="/findusadata")
	public ResponseEntity<?> getUSAData() {
		//add headers from orgSpring package set headers and then call rest template
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<?> httpEntity = new HttpEntity<>(headers);
		
		//exchange calls other API, if you don't return type then it should be String.class
		//exchange is used for all operations
		ResponseEntity<?> response = restTemplate.exchange("https://datausa.io/api/data?drilldowns=Nation&measures=Population", HttpMethod.GET, httpEntity, String.class);	
		return response;
	}
	
	//Second way to get for external URL
	@GetMapping(value="/findusadata2")
	public ResponseEntity<?> getUSAData2() {
		//getForEntity is only used for specific operations
		ResponseEntity<?> response = restTemplate.getForEntity("https://datausa.io/api/data?drilldowns=Nation&measures=Population", String.class);	
		return response;
	}
	
	//First way to get using Rest template
	@GetMapping(value="/findallcustomersresttemplate")
	public ResponseEntity<?> findAllCustomersUsingRestTemplate() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<?> httpEntity = new HttpEntity<>(headers);
		
		//calling same class API
		//because we know findAll has a return type of List we can do List.class, but we can do String.class but it convert internally to List
		ResponseEntity<?> response = restTemplate.exchange("http://localhost:7777/om/customer/v1/findall", HttpMethod.GET, httpEntity, List.class);
		return response;
	}
	
	//Second way to get using Rest template
	@GetMapping(value="/findallcustomersresttemplate2")
	public ResponseEntity<?> findAllCustomersUsingRestTemplate2() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<?> httpEntity = new HttpEntity<>(headers);
		
		//calling same class API
		//because we know findAll has a return type of List we can do List.class, but we can do String.class but it convert internally to List
		ResponseEntity<?> response = restTemplate.getForEntity("http://localhost:7777/om/customer/v1/findall", List.class);
		return response;
	}
	
	//Rest template for post operation
	@PostMapping(value="/savecustomersresttemplate")
	public ResponseEntity<?> saveCustomersUsingRestTemplate(@RequestBody CustomerRequest customerRequest) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<?> httpEntity = new HttpEntity<>(customerRequest, headers);
		
		ResponseEntity<?> response = restTemplate.exchange("http://localhost:7777/om/customer/v1/save", HttpMethod.POST, httpEntity, String.class);
		return response;
	}
	
	//Rest template for post operation
	@PostMapping(value="/savecustomersresttemplate2")
	public ResponseEntity<?> saveCustomersUsingRestTemplate2(@RequestBody CustomerRequest customerRequest) {
		HttpEntity<?> httpEntity = new HttpEntity<>(customerRequest);
		ResponseEntity<?> response = restTemplate.postForEntity("http://localhost:7777/om/customer/v1/save", httpEntity, String.class);
		return response;
	}


}