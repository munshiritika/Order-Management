package com.example.spingboot.ordermanagement.dao;
//02-28-2024, Wednesday

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.spingboot.ordermanagement.model.Customer;

@Repository  //it is repository interface which does database operation
public interface CustomerDao extends JpaRepository<Customer, Long>{
	//@Query - we can write our own customized queries
	@Query(nativeQuery = true, value = "SELECT * FROM customer where email = :inputEmail")
	public Customer getCustomerByEmail(String inputEmail);
	
	@Query(nativeQuery = true, value = "SELECT * FROM customer where address like %:inputCity%")
	public List<Customer> getCustomersBasedOnCity(String inputCity);
}
