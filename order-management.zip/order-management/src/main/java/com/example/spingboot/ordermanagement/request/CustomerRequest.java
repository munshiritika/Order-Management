package com.example.spingboot.ordermanagement.request;
//02-28-2024, Wednesday
import lombok.Data;
@Data
public class CustomerRequest {
	private String customerName;
	private String email;
	private String mobile;
	private String address;
	private String password;
}
