package com.example.spingboot.ordermanagement.util;
//03-13-2024, Wednesday

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
		//any error or exception occurs that will be handled inside the authentication point
		//whatever request you are sending is unauthorized
		//if token is not valid you will get exception -> for handling those exception in spring security you have entry point -> that exception will come here and send response as unauthorized status here
		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
		
	}

}
