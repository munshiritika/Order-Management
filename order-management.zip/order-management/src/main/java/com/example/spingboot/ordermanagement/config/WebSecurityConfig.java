package com.example.spingboot.ordermanagement.config;
//03-14-2024, Thursday

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.spingboot.ordermanagement.service.JwtUserDetailsService;
import com.example.spingboot.ordermanagement.util.JwtAuthenticationEntryPoint;
import com.example.spingboot.ordermanagement.util.JwtFilter;

@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;
	@Autowired
	private JwtFilter jwtFilter;
	
	@Bean
	public PasswordEncoder passwordEncoderBean() {
		//encrypting the password in the form of bean
		return new BCryptPasswordEncoder();
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		//taking jwtUserDetailsService class and inside that passwordEncoder is happening with the passwordEncoderBean
		//passwordEncoderBean will deCrypt using passwordEncoderBean algorithm we wrote above
		auth.userDetailsService(jwtUserDetailsService).passwordEncoder(passwordEncoderBean());
	}
	
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		//which permission has to be given to the user or not
		//CSRF is able to protection again any cross site
		//csrf().disable() will not allow any third part access to it and then we are authorizing the requests meaning ig anything matches to the URL login we are giving permission all
		http.csrf().disable().authorizeRequests().antMatchers("/login").permitAll()
		.antMatchers("/om/customer/v1/save").permitAll()
		.anyRequest().authenticated().and().exceptionHandling().authenticationEntryPoint(jwtAuthenticationEntryPoint)
		.and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
		
	}
}
