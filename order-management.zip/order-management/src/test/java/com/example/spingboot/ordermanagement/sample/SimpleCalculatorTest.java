package com.example.spingboot.ordermanagement.sample;
//03-08-2024, Friday

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class) // this runs SimpleCalculatorTest as JUnit tests
public class SimpleCalculatorTest {
SimpleCalculator simpleCalculator = new SimpleCalculator();
	
	@Test // it considers this method as a single test case to run
	public void sumTestPositive() {
		int actualResponse = simpleCalculator.sum(10, 2);
		assertNotNull(actualResponse);
		assertEquals(12, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void sumTestNegative() {
		int actualResponse = simpleCalculator.sum(10, 2);
		assertNotNull(actualResponse);
		assertNotEquals(15, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void diffTestPositive() {
		int actualResponse = simpleCalculator.diff(10, 2);
		assertNotNull(actualResponse);
		assertEquals(8, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void diffTestNegative() {
		int actualResponse = simpleCalculator.diff(10, 2);
		assertNotNull(actualResponse);
		assertNotEquals(3, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void mulTestPositive() {
		int actualResponse = simpleCalculator.mul(10, 2);
		assertNotNull(actualResponse);
		assertEquals(20, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void mulTestNegative() {
		int actualResponse = simpleCalculator.mul(10, 2);
		assertNotNull(actualResponse);
		assertNotEquals(22, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void divTestPositive() {
		int actualResponse = simpleCalculator.div(10, 2);
		assertNotNull(actualResponse);
		assertEquals(5, actualResponse);
	}
	
	@Test // it considers this method as a single test case to run
	public void divTestNegative() {
		int actualResponse = simpleCalculator.div(10, 2);
		assertNotNull(actualResponse);
		assertNotEquals(22, actualResponse);
	}
}
