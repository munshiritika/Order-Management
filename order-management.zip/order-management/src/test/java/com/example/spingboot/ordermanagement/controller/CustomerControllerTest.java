package com.example.spingboot.ordermanagement.controller;
//03-11-2024, Monday

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.spingboot.ordermanagement.model.Customer;
import com.example.spingboot.ordermanagement.request.CustomerRequest;
import com.example.spingboot.ordermanagement.response.CustomerResponse;
import com.example.spingboot.ordermanagement.service.CustomerService;

@RunWith(SpringRunner.class)
public class CustomerControllerTest {
	//MockiTo provides a way to imitate the APIs and framework and we can get the output
	
	//injection of the class you are doing testing
	@InjectMocks  
	private CustomerController customerController;
	
	//autoWire in normal class
	@Mock  
	private CustomerService customerService;
	
	//initializes your MockiTo annotations
	@BeforeEach //before running each and every test case this set up method gets called
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	//this is the request payLoad, create response under payLoad
	private CustomerRequest getCustomerRequest() {
		CustomerRequest customerRequest = new CustomerRequest();
		customerRequest.setCustomerName("Ritika");
		customerRequest.setEmail("ritika123@gmail.com");
		customerRequest.setMobile("3018907765");
		customerRequest.setAddress("123 University Blvd, Silver Spring, MD, USA");
		customerRequest.setPassword("ritika@");
		return customerRequest;
	}
	
	//this is the response, get response to check if it is meeting the actual with the expected
	private Customer getCustomer() {
		Customer customer = new Customer();
		customer.setCustomerId(123);
		customer.setCustomerName("Ritika");
		customer.setEmail("ritika123@gmail.com");
		customer.setMobile("3018907765");
		customer.setAddress("123 University Blvd, Silver Spring, MD, USA");
		customer.setPassword("ritika123");
		return customer;
	}
	
	@Test
	public void createCustomerTestPositive() {
		//when we calling other methods in code from different class
		//then we need to do mocking of that thing
		//mockito.when -- mocking whatever you calling inside this
		//return object is customer object which is saved customer so we do thenReturn and return customer object
		Mockito.when(customerService.saveCustomer(Mockito.any())).thenReturn(getCustomer());
		//calling actual method
		ResponseEntity<?> actualResponse = customerController.createCustomer(getCustomerRequest());
		assertNotNull(actualResponse);
		//expected result, actual result
		assertEquals(getCustomer(), actualResponse.getBody());
	}
	
	@Test
	public void createCustomerTestNegative() {
		//thenThrow(new RuntimeException()) covers catch block		
		Mockito.when(customerService.saveCustomer(Mockito.any())).thenThrow(new RuntimeException());
		ResponseEntity<?> actualResponse = customerController.createCustomer(getCustomerRequest());
		assertNotNull(actualResponse);
		
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setData(null);
		customerResponse.setMessage("Customer not saved successfully.");
		customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		
		assertEquals(customerResponse, actualResponse.getBody());
	}
	
	@Test
	public void findAllCustomersTestPositive() {
		List<Customer> customerlist = new ArrayList<>();
		customerlist.add(getCustomer());
		Mockito.when(customerService.getAllCustomers()).thenReturn(customerlist);
		ResponseEntity<?> actualResponse = customerController.findAllCustomers();
		assertNotNull(actualResponse);
		assertEquals(customerlist, actualResponse.getBody());
	}
	
	@Test
	public void findAllCustomersTestNegative() {
		Mockito.when(customerService.getAllCustomers()).thenThrow(new RuntimeException());
		ResponseEntity<?> actualResponse = customerController.findAllCustomers();
		assertNotNull(actualResponse);
		
		CustomerResponse customerResponse = new CustomerResponse();
		customerResponse.setData(null);
		customerResponse.setMessage("All Customer not found successfully.");
		customerResponse.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		
		assertEquals(customerResponse, actualResponse.getBody());
	}

//	@Test
//	public void findCustomerByIdTestPositive() {
//		Mockito.when(customerService.getCustomerById(Mockito.any())).thenReturn(getCustomer());
//		ResponseEntity<?> actualResponse = customerController.findCustomerById(getCustomerRequest());
//		assertNotNull(actualResponse);
//		assertEquals(getCustomer(), actualResponse.getBody());
//	}
	
//	@Test
//	public void findCustomerCountTestPositive() {
//		long count=0;
//		Mockito.when(customerService.getAllCustomersCount()).thenReturn(count);
//		ResponseEntity<?> actualResponse = customerController.findCustomerCount();
//		assertNotNull(actualResponse);
//		assertEquals(count, actualResponse.getBody());
//	}
}
