package com.example.spingboot.ordermanagement.service;
//03-11-2024, Monday

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.example.spingboot.ordermanagement.dao.CustomerDao;
import com.example.spingboot.ordermanagement.model.Customer;
import com.example.spingboot.ordermanagement.request.CustomerRequest;

@RunWith(SpringRunner.class) 
public class CustomerServiceTest {
	@InjectMocks
	private CustomerService customerService;
	
	@Mock
	private CustomerDao customerDao;
	
	@BeforeEach // before running each and every test case this set up method gets called
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	// this is the request payload
	private CustomerRequest getCustomerRequest() {
		CustomerRequest customerRequest = new CustomerRequest();
		customerRequest.setCustomerName("test");
		customerRequest.setEmail("test123@gmail.com");
		customerRequest.setMobile("+234565432");
		customerRequest.setAddress("12,shsj,sii,siiwi");
		customerRequest.setPassword("shjiwiw");
		return customerRequest;
	}
	
	// this is the response 
	private Customer getCustomer() {
		Customer customer = new Customer();
		customer.setCustomerId(123L);
		customer.setCustomerName("test");
		customer.setEmail("test123@gmail.com");
		customer.setMobile("+234565432");
		customer.setAddress("12,shsj,sii,siiwi");
		customer.setPassword("shjiwiw");
		return customer;
	}
	
	@Test
	public void saveCustomerTestPositive() {
		Mockito.when(customerDao.save(Mockito.any())).thenReturn(getCustomer());
		Customer actualResponse = customerService.saveCustomer(getCustomerRequest());
		assertNotNull(actualResponse);
		assertEquals(getCustomer(), actualResponse);
	}
	
	@Test
	public void saveCustomerTestNegative() {
		Mockito.when(customerDao.save(Mockito.any())).thenReturn(null);
		assertThrows(RuntimeException.class, ()-> customerService.saveCustomer(getCustomerRequest()));
	}
	
	@Test
	public void getAllCustomersTestPositive() {
		List<Customer> customerlist = new ArrayList<>();
		customerlist.add(getCustomer());
		Mockito.when(customerDao.findAll()).thenReturn(customerlist);
		List<Customer> actualResponse = customerService.getAllCustomers();
		assertNotNull(actualResponse);
		assertEquals(customerlist, actualResponse);
	}
	
	@Test
	public void getAllCustomersTestNegative() {
		List<Customer> customerlist = new ArrayList<>();
		Mockito.when(customerDao.findAll()).thenReturn(customerlist);
		assertThrows(RuntimeException.class, ()-> customerService.getAllCustomers());
	}
}
